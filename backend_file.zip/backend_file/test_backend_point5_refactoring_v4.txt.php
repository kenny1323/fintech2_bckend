<?php

//create class Film
//this class has 2 fields, _title and _priceCode
class Film
{
	
	
 //create the costructor of the class Film	
 public function __construct($title, $priceCode)
 {
  $this->_title = $title;
  $this->_priceCode = $priceCode; 
 }

	
 //Here there is a list of get() and set() methods to set and get the 2 field _title and _priceCode
 //START DEFINITION OF SETS AND GETS METHODS
	
 /* @return _priceCode */	
 public function getPriceCode() 
 {
  return $this->_priceCode; 
 } 
 
 
 public function setPriceCode($value) 
 {
  $this->_priceCode = $value; 
 }

	
 /* @return _title */	
 public function getTitle() 
 {
  return $this->_title; 
 }
 //END DEFINITION OF SETS AND GETS METHODS

 
 //Here we define _title and _priceCode. 
 private $_title; 
 private $_priceCode;
	
 //Define and initialize 3 costants	
 const CHILDRENS = 2; 
 const REGULAR = 0; 
 const NEW_RELEASE = 1; 
} 
 
 





//DEFINITION OF THE CLASS RENTAL
//This class has 2 fields _film and _daysRented
class Rental 
{

  //create the costructor of the class Rental	
  public function __construct($film, $daysRented)
  {
	$this->_film = $film;
	$this->_daysRented = $daysRented; 
  }
  
 
/* @return _daysRented */
  public function getDaysRented() 
  {
   return $this->_daysRented; 
  }
	 
	 
/* @return _film */
 public function getFilm() 
 {
 return $this->_film; 
 }
	 
	 
 //Define  _film  and _daysRented;
 private $_film; 
 private $_daysRented; 
} 

















//DEFINITION OF THE CLASS Customer
//This class has 2 fields _name and _rentals;
//The field _name is the name of the customer;
//The field _rentals is an array of rented film;
class Customer 
{
 	
 //create the costructor of the class Rental	
 public function __construct($name)
 {
  $this->_name = $name;
  $this->_rentals = array(); 
 }
	 
	 
 //push the next film in the array of the rented film, namely _rentals 	
 public function addRental($rental)
 {
  array_push($this->_rentals, $rental); 
 }
	 
 //get the name of the customer	 
 /* @return _name */	
 public function getName() 
 {
  return $this->_name; 
 } 
	 
	 
 //Create the table $result;	
 public function getStatement() 
 {
 $totalAmount = 0; 
 
 //loyalty rewards; loyalty program;
 $frequentRenterPoints = 0 ; 

 //Create a message like this: "Rental Record for John Smith" 	 
 $result = "Rental Record for " . $this->getName() . "\n"; 
	 
	 
 //This foreach create the table of the rentals for a given customer (John Smith);	 
 //This table is stored into the varaible $result;
 foreach ($this->_rentals as $rental) 
 {
  /* @var $rental Rental */
  $thisAmount = 0 ;
  //determine amounts for each line 
  switch($rental->getFilm()->getPriceCode()) 
  {
		  
   //Set $thisAmount in the case the PriceCode is REGULAR		  
   case Film::REGULAR:
   $thisAmount += 2; 
   if($rental->getDaysRented() > 2) {$thisAmount += ($rental->getDaysRented() - 2) * 1.5;} 
   break; 


   //Set $thisAmount in the case the PriceCode is NEW_RELEASE		  
   case Film::NEW_RELEASE:
   $thisAmount += $rental->getDaysRented() * 3;
   break; 

		  
   //Set $thisAmount in the case the PriceCode is CHILDRENS		  
   case Film::CHILDRENS: 
   $thisAmount += 1.5; 
   if($rental->getDaysRented() > 3) {$thisAmount += ($rental->getDaysRented() - 3) * 1.5; }

   break; 
  }
	 
	 
  //add frequent renter points (loyalty rewards)
  $frequentRenterPoints++;
  
  //add bonus for a two day new release rental 
  if(($rental->getFilm()->getPriceCode() == Film::NEW_RELEASE) && ($rental->getDaysRented() > 1)) {$frequentRenterPoints++};

	 
  //show figures for this rental
  //I am not sure the first tab is necessary;
  $result .= "\t" . $rental->getFilm()->getTitle() . "\t" . $thisAmount . "\n";
  $totalAmount += $thisAmount; 
 } //end foreach
	 
 return $result; 
}
 
//Define private fileds	 
private $_name; 
private $_rentals; 
}


?>





/*
POINT 5.1. I have added the braces to any if costruct; 
POINT 5.2. I have added some comments;
POINT 5.3. I have added some annotation like @return _name 

*/








